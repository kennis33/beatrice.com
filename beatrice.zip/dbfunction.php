<?php
include("db.php");

   $file_name = $_FILES['image']['name'];      
   $file_tmp = $_FILES['image']['tmp_name'];
   $file_size = $_FILES['image']['size'];
   $file_type = $_FILES['image']['type'];
   $file_error = $_FILES['image']['error'];
   $name=  $_POST["name"];
   $price=  $_POST["price"];
   $category= $_POST["Category"];
   $discription= $_POST["discription"];

  $slitextension= explode('.', $file_name);
  $extension= strtolower(end($slitextension));
  $extensioncheck= array('png','jpg','jpeg', 'jfif');

  if(in_array($extension, $extensioncheck)){
   
$filenewname= "img".uniqid().".".$extension;

$dirfolder = "images/".$filenewname;

$fileuploaded = move_uploaded_file($file_tmp, $dirfolder);




if ($category == "native") {
  $query= "INSERT INTO native(post_image,name, price
  , category,discription) VALUES ('$filenewname','$name', '$price' ,'$category','$discription')";

  $result = mysqli_query($db,$query);

  header("location:admin.php?success= successfully upload");

}elseif ($category == "women") {
  $query= "INSERT INTO women(post_image,name, price
  , category,discription) VALUES ('$filenewname','$name', '$price' ,'$category','$discription')";

  $result = mysqli_query($db,$query);

  header("location:admin.php?success= successfully upload");
}elseif ($category == "men") {
  $query= "INSERT INTO men(post_image,name, price
  , category,discription) VALUES ('$filenewname','$name', '$price' ,'$category','$discription')";
  
 $result = mysqli_query($db,$query);

  header("location:admin.php?success= successfully upload");
}elseif ($category == "bag") {
  $query= "INSERT INTO bag(post_image,name, price
  , category,discription) VALUES ('$filenewname','$name', '$price' ,'$category','$discription')";

  $result = mysqli_query($db,$query);

  header("location:admin.php?success= successfully upload");
}else{
  echo "Upload fail";
}



   



  }else{
    echo "please upload only jpg,png,jpeg , jfif image";
  }


?>