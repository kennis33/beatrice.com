<?php
include('db.php');
include('header.php');



// verity paystack

$curl = curl_init();
// TOURN OFF SSL

 curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, true);
// get the refernce code from url
if(!empty($_GET["reference"])){
    // clean the reference code
    $sanitize = filter_var_array($_GET, FILTER_SANITIZE_STRING);
    $reference = rawurlencode($sanitize["reference"]);

}else{
    die("No reference was supplied! ");
}
// set the configuration
curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/transaction/verify/" .$reference,
    CURLOPT_RETURNTRANSFER => true,
    // set the headers
    CURLOPT_HTTPHEADER => [
        "accept: application/json",
        "Authorization: Bearer sk_live_b3291d21d9c7b273a95ad5f943476fc69ff45755",
        "cache-control: no-cache"
        
    ]

)

    );
    // execute cURL
    $response = curl_exec($curl);
    $err = curl_error($curl);
    if($err){
        die("cURL returned some error: ". $err);

    }
    // var_dump( $response);
    $tranx = json_decode($response) ;
    if(!$tranx->status) {
      die("API returned some error:" .$tranx->message );
    }
    if('success'== $tranx->data->status){
        $amount = $tranx->data->amount;
        $email = $tranx->data->customer->email;
        $ref = $tranx->data->reference;
        $product_name =$tranx->data->metadata->custom_fields[0]->value ; 
        $product_discription =$tranx->data->metadata->custom_fields[1]->value ;
    }else{
        die("Transaction not found");

    }

 
   
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" css/bootstrap.min.css" >
    <link rel="stylesheet" href="style.css">
</head>
<body>


        <div class="verifycon">
            <h2>Thanks you! for buying <?php echo  $product_name;?><span> At Beatrice Wears</span></h2>
            <div class="verifytext">
        <p><span>Customer Email:</span> <?php echo$email;?></p> 
        <h3><span>Reference:</span> <?php echo $ref;?> </h3>
        <h3><span>Product Name:</span><?php echo  $product_name;?> </h3>
        <h3><span>Product Discription:</span><?php echo  $product_name;?> </h3>
        <h3><span>Amount:</span><?php echo  $amount / 100;?> </h3>
            </div> 
        

    </div>
<button onclick= "window.print()">Print Form</button>
    </div><br>
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php include ('footer.php');
?>