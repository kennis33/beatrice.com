<?php



?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" css/bootstrap.min.css" > 
    <link rel="stylesheet" href="style.css">
</head>
<body>
<div class="footercontainer">
    <div class="footermedia">
      <div class="callus">
      <img src="icon/phone.png" alt="">
      <div class="fcallimg">
      <h4>Call us</h4> 
      <p>+234 9038415618</p>
      </div>
      </div>
      <div class="callus">
      <img src="icon/mail.png" alt="">
      <div class="fcallimg">
      <h4>Mail us</h4> 
      <p>support@beatricewears.ga</p>
      </div>
      </div>
      <div class="callus">
      <img src="icon/follow.png" alt="">
      <div class="fcalimg">
      <h4>Follow us</h4> 
      <p>
         <img src="icon/f.png" alt="">
         <img src="icon/t.png" alt="">
         <img src="icon/i.png" alt="">
         <img src="icon/w.png" alt="">
    </p>
      </div>
      </div>
    </div>

    <div class="footerwrpper">

        <div class="footerabout">
            <h3>About Us</h3>
            <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit.<br> Ut tempus placerat risus, ut rhoncus arcu.<br> Vestibulum consectetur rutrum neque non commodo.<br> Fusce ac metus purus.<br> Ut in laoreet ante. Nam tincidunt pretium consequat. <br>Aliquam erat volutpat. Nullam eu ultrices lacus, vel posuere tortor. <br>In pulvinar metus turpis, sed cursus justo porta sed.<br>  </p>
        </div>

        <div class="footerproduct">
        <h3>Categories of wears</h3>
          
               <a href="native.php">Native</a><br>
                <a href="women.php">Women Wears</a><br>
                <a href="men.php">Men Wears</a><br>
                <a href="bag.php">Bags</a>
          
        </div>

        <div class="footercontact">
        <h3>Contacts</h3>
        <p><span>Adress: </span>Gbaremu market, along Eleyele, <br>Sango road, Ibadan </p>
        <p><span>Email: </span>support@beatricewears.ga </p>
        <p><span>Phone: </span>+234 9038415618 </p>
        </div>

    </div>



    <p class="copyright">Copyright &copy; KennikTech <span><?php echo date("Y");?></span>. All Rights Reserved</p>

</div>
   


   
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>