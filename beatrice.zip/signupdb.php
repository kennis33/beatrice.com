<?php 
include("db.php");
$firstname = $_POST["firstname"];
$lastname = $_POST["lastname"];
$email = $_POST["email"];
$password = $_POST["password"];
$r_password = $_POST["r_password"];
$query = "INSERT INTO signup(firstname, lastname, email, password, r_password) VALUES('$firstname', '$lastname', '$email','$password','$r_password')";
    

$result = mysqli_query($db,$query);


if (!$result) {
    echo "something went wrong";
 }else {
    header("location: login.php?msg=successfull");
 }
?>
