<?php include("header.php");
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
<link rel="stylesheet" href=" css/bootstrap.min.css" >
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <link rel="stylesheet" href="style.css">
 
    
</head>
<body>

        <!-- section one start-->
        <div class="wrappercontainer">

<div class="topwrapper">
<div class="firstcontent">
<h1>super<span>Deals</span></h1>
</div>
<div class="secondcontent">
<p>top product incredible price</p>
</div>
<div class="thirdcontent">
<p><a href="men.php">View more</a></p>
</div>
</div>

<!-- ======= -->
<div class="imagewrapper">

<div class="wrappercategory">
    <h2>Category</h2>
    <div class="categorycontent">
        <ul>
        <li><a href="native.php">Native</a></li>
        <li><a href="women.php">Women Wears</a></li>
        <li><a href="men.php">Men Wears</a></li>
            
        <li><a href="bag.php">Bags</a></li>
            
        </ul>
    </div>
</div>
<!-- MEN -->

<?php 
            $query= "SELECT * FROM men LIMIT 6";
            $result = mysqli_query($db,$query);

            while($row = mysqli_fetch_array($result)){
         ?> 
         
<div class="wrapperimagecontainer">
    
<div class="imgcontainerwrapper">
<img src="images/<?php echo $row['post_image']?>">
   
</div>
<div class="last">
<h2><span>ngn</span><?php echo $row['price'] ?></h2>

<h4><span></span> <?php echo $row['name'] ?></h4>
<div class="acon">
<a href="mendb.php?product=<?php echo $row['id']?>">Buy me</a>
</div> 
</div>
</div>

           <?php } ?>

</div>


</div>
<!-- NATIVE  ======= -->

<div class="nativecontainer">

<div class="nativemore">
<p><a href="native.php">View more</a><p>
</div>
<?php 
            $query= "SELECT * FROM native LIMIT 4";
            $result = mysqli_query($db,$query);

            while($row = mysqli_fetch_array($result)){
         ?> 
<div class="nativeimgtext">

<div class="nativeimg">
<img src="images/<?php echo $row['post_image']?>">
</div>
<div class="nativetext">
<h2><span></span> <?php echo $row['name'] ?></h2>
<h4><span>ngn</span><?php echo $row['price'] ?></h4>
<div class="acon">
<a href="nativedb.php?product=<?php echo $row['id']?>">Buy me</a>
</div>
</div>

</div>
<?php } ?>

</div>
<!-- end native -->

<!-- =============  WOMEN  ========== -->
<div class="womencontainer">
<div class="nativemo">
<p><a href="women.php" syle= "text-decoration: none;">View more</a><p>
</div>
<div class="womenwrapper">
<?php 
            $query= "SELECT * FROM women LIMIT 6";
            $result = mysqli_query($db,$query);

            while($row = mysqli_fetch_array($result)){
         ?> 




<div class="womenimgcontent">
<div class="womenimage">
<img src="images/<?php echo $row['post_image']?>">
   
</div>
<div class="womencontant">
<h2><span>ngn</span><?php echo $row['price'] ?></h2>
<h4><span></span> <?php echo $row['name'] ?></h4>
<div class="acon">
<a href="womendb.php?product=<?php echo $row['id']?>">Buy me</a>
</div> 
</div>
</div>
<?php } 
?>
</div>


</div>
<!-- WOMEN END -->

<!-- BAG START -->

<div class="bagcontainer">
<div class="nativemo">
<p><a href="bag.php">View more</a><p>
</div>
<div class="bagwrapper">
<?php 
            $query= "SELECT * FROM bag LIMIT 5";
            $result = mysqli_query($db,$query);

            while($row = mysqli_fetch_array($result)){
         ?> 



   <div class="bagimagecontent">
    <div class="bagimage">
    <img src="images/<?php echo $row['post_image']?>">
    
    </div>
    <div class="bagcontent">
        <h4><span>ngn</span><?php echo $row['price'] ?></h4>
        <p><?php echo $row['name'] ?></p>
        <div class="acon">
<a href="bagdb.php?product=<?php echo $row['id']?>">Buy me</a>
</div> 
    </div>
   </div> 




<?php } 
?>
</div>
</div>
<!-- BAG END -->
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php include ('footer.php')?>