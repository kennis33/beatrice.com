<?php 
session_start();
include("db.php");
$email= $_POST["email"];
$password= $_POST["password"];
$query= "SELECT * FROM signup WHERE email='$email'";
$result= mysqli_query($db,$query);
if (mysqli_num_rows($result) > 0) {

    $row= mysqli_fetch_array($result);
     
     if($row['password'] == $password){
      $_SESSION['userId'] = $row['id'];
      header("location: user.php?msg=thank for login");
     }else {
        echo "wrong password";
      }
 
}else{
    header("location: signup.php?msg=please registered first here");
}

?>