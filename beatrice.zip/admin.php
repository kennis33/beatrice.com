<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" css/bootstrap.min.css" > 
    <link rel="stylesheet" href="style.css">
</head>
<body>
<h2>AMDIN PANEL</h2>
<div class="admincontainer">

    <div class="adminup">
        <h4>Admin Dashboard</h4>
        <div class="adminlist">
        <ul>
        <li><a href="delete/native1.php">Native</a></li>
        <li><a href="delete/women1.php">Women Wears</a></li>
        <li><a href="delete/men1.php">Men Wears</a></li>
            
        <li><a href="delete/bag1.php">Bags</a></li>
            
        </ul>
        </div>
    </div>
    
    <div class="admin">

        <form action="dbfunction.php" method="POST" enctype="multipart/form-data">
            <div class="admininput">
            <input type="file" name="image" id="" required>
            <br>
          <input type="text" name="name" id="" placeholder= "Enter the product name"required> <br>
          <input type="text" name="price" id="" placeholder= "Enter the product price"required> <br>
          <input type="text" name="discription" id="" placeholder= "Enter the product discription"required> <br>
<select name="Category" id="">
    <option value="native">Native</option>
    <option value="women">Women's </option>
    <option value="men">Men's</option>
    <option value="bag">Bag's</option>
</select>
          </div><br>
          <button type="submit">Upload</button>
        </form>    
    </div>

</div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>