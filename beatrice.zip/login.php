<?php include("header.php");
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="singupformcontainter">
        <div class="signupwrapper">
            <div class="signupform">
             <form action="logindb.php" method="post">
                
                <input type="email" name="email" id="" placeholder= "Enter your email"required><br>
                <input type="password" name="password" id="" placeholder= "Enter your password"required><br>
                
                <div class="signupbtn">
                    <button type="submit">Login</button>
                </div>

             </form>
            Don't have an account? <a href="signup.php" target="_blank" rel="noopener noreferrer">Sign up</a>

            </div>


        </div>
    </div>
    
</body>
</html>








<?php include ('footer.php')?> 