<?php include("header.php");
include("db.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
 <link rel="stylesheet" href="style.css">

</head>
<body>
    <div class="singupformcontainter">
        
        <div class="signupwrapper">
            <div class="signupform">
            <h3>Sign Up</h3>
             <form action="signupdb.php" method="POST">
                <input type="text" name="firstname" id="" placeholder= "Enter your firstname"required><br>
                <input type="text" name="lastname" id="" placeholder= "Enter your lastname"required><br>
                <input type="email" name="email" id="" placeholder= "Enter your email"required><br>
                <input type="password" name="password" id="" placeholder= "Enter your password"required><br>
                <input type="password" name="r_password" id="" placeholder= "Enter your name"required>
                <div class="signupbtn">
                    <button type="submit">Signup</button>
                </div>
             </form>
            

            </div>


        </div>
    </div>
    
</body>
</html>








<?php include ('footer.php')?> 