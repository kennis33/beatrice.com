<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="//use.fontawesome.com/releases/v6.0.0/css/all.css">
    <link rel="stylesheet" href=" css/bootstrap.min.css" > 
    <link rel="stylesheet" href="style.css">
    <title>Beatrice wears</title>
</head>
<body>

<div class="navparent">
    <div class="logo">
        <h5>BEATRICE <span>Wears</span></h5>
    </div>
    <div class="navchild">
<div class="icon"><i class="fa-solid fa-bars"onclick="openTab()"></i></div>
<ul class="topnav">
    
  <li><a class="active" href="index.php">Home</a></li>
  <li><a href="contact.php">Contact</a></li>
  <li class="right"><a href="about.php">About</a></li>
</ul>
</div>
</div>



    <!-- for -->

<script>
    
    var a = 0;
    function openTab(){
        if (a=="0"){
            document.querySelector(".topnav").style.display= "block";
            a= 1;
   }else{
            document.querySelector(".topnav ").style.display= "none";
           a=0;
       }
    }
</script>
<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>