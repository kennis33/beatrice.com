<?php 

include("../db.php");
?>
<?php
$id =  $_GET['product'];

$query ="DELETE  FROM women WHERE id ='$id' ";
$result = mysqli_query($db, $query);

header("location: women1.php?msg=successfully deleted");

?>