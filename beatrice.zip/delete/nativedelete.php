<?php 

include("../db.php");
?>
<?php
$id =  $_GET['product'];

$query ="DELETE  FROM native WHERE id ='$id' ";
$result = mysqli_query($db, $query);

header("location: native1.php?msg=successfully deleted");

?>