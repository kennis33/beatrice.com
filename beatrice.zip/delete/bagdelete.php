<?php 

include("../db.php");
?>
<?php
$id =  $_GET['product'];

$query ="DELETE  FROM bag WHERE id ='$id' ";
$result = mysqli_query($db, $query);

header("location: bag1.php?msg=successfully deleted");

?>