<?php include("header.php");

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" css/bootstrap.min.css" > 
    <link rel="stylesheet" href="style.css">
</head>
<body>
   <div class="contactcontainer">
   
        <div class="contactimg">
            <img src="images/contact_us_image.jpg" alt="">
        </div>
                        
                                    
            <div class="contactform">
                <form method="post" action="contact-us.php" >
                    <input type="text" name="name" id="" placeholder="Enter your name"required><br>
                    <input type="text" name="email" id="" placeholder="Enter your email"required><br>
                    <input type="text" name="subject" id="" placeholder="Enter subject"required><br>
                    <textarea name="message" id="" cols="5" rows="7"placeholder="Enter your message" required></textarea>
                    <div class="contactbtn">
                        <button type="submit">Send</button>
                    </div>
                 </form>
            </div>
            

    </div>

<script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php include ('footer.php')?>