<?php
include('db.php');
include('header.php');
$product =  $_GET['product'];


$query ="SELECT * FROM native WHERE id = '$product'";

$result = mysqli_query($db, $query);

$row = mysqli_fetch_array($result);


if(isset($_GET["product"])){
    $id= htmlspecialchars($_GET["product"]);
    $product_name = $row['name'];
    $product_price = $row['price'];
    $product_discription= $row["discription"];
 
}else{
    header('location: index.php?empty= please select the product to continue!' );
}
// Declare string value
$price = ($row[('price')]) ;

 // Check if string in numaric
if (is_numeric($price)){
	
	// Convert string to integer using intval function
    intval($price);
	
	
 }
// Integrate Paystack
if(isset($_POST["submit"])){
    $email = htmlspecialchars($_POST["email"]);
   



 $url = "https://api.paystack.co/transaction/initialize";
 $fields = [
   'email' =>  $email,
   'amount' =>  $price *100,
  "callback_url" => "https://beatricewears.ga/verify.php",
"metadata" => [
  "custom_fields"=>[
      [
          "display_name" => "name",
          "varible_name"=> "name",
          "value" => $product_name
      ],
      [
          "display_name" => "price",
          "varible_name"=> "price",
          "value" => $product_price
      ],
      [
          "display_name" => "discription",
          "varible_name"=> "discription",
          "value" => $product_discription
      ],
  ]
]

 ];

 $fields_string = http_build_query($fields);

 //open connection
 $ch = curl_init();
 
 //set the url, number of POST vars, POST data
 curl_setopt($ch,CURLOPT_URL, $url);
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
 curl_setopt($ch, CURLOPT_HTTPHEADER, array(
   "Authorization: Bearer sk_live_b3291d21d9c7b273a95ad5f943476fc69ff45755",
   "Cache-Control: no-cache",
 ));
 
 //So that curl_exec returns the contents of the cURL; rather than echoing it
 curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 
 
 //execute post
 $result = curl_exec($ch);
 echo $result;
 $transaction= json_decode( $result );
 header("location:". $transaction->data->authorization_url);
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href=" css/bootstrap.min.css" >
    
    <link rel="stylesheet" href="style.css">
</head>
<body>
    <!--  -->
<h1>welcome To <span>Beatrice Wears</span></h1>
    <hr> 
    <div class="morecontainer">

    
        <div class="product">
            
            <h3><span>Name:</span><?php echo $row['name'] ?>  </h3>
            <small><span> Product price:</span> &#8358; <?php echo $row['price']?></small>
            <p><span>Product discription:</span><?php echo $row['discription'] ?> 
            </p>
            <div class="imgmore">
            
            <img src="images/<?php echo $row['post_image']?>">
            </div>
            
            <div class="allform">
            <form action="" method="POST">
             <label for="">Email</label>
             <input type="email" name="email" id="" placeholder= "enter your email" required><br>
             <input type="submit" name="submit" value= "Order Now">
            </form>
            </div>
            
        </div>
<hr>
       
        

    </div>
    <!--  -->
    <script src="https://code.jquery.com/jquery-3.4.1.slim.min.js" integrity="sha384-J6qa4849blE2+poT4WnyKhv5vZF5SrPo0iEjwBvKU7imGFAV0wwj1yYfoRSJoZ+n" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/popper.js@1.16.0/dist/umd/popper.min.js" integrity="sha384-Q6E9RHvbIyZFJoft+2mJbHaEWldlvI9IOYy5n3zV9zzTtmI3UksdQRVvoxMfooAo" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js" integrity="sha384-wfSDF2E50Y2D1uUdj0O3uMBJnjuUD4Ih7YwaYd1iqfktj0Uod8GCExl3Og8ifwB6" crossorigin="anonymous"></script>
</body>
</html>
<?php include ('footer.php');
?>