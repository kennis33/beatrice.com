<form id="paymentForm">
  <div class="form-group">
    <label for="email">Email Address</label>
    <input type="email" id="email-address" required />
  </div>
  <div class="form-group">
    <label for="amount">Amount</label>
    <input type="tel" id="amount" required />
  </div>
  <div class="form-group">
    <label for="first-name">First Name</label>
    <input type="text" id="first-name" />
  </div>
  <div class="form-group">
    <label for="last-name">Last Name</label>
    <input type="text" id="last-name" />
  </div>
  <div class="form-submit">
    <button type="submit" onclick="payWithPaystack()"> Pay </button>
  </div>
</form>

<script src="https://js.paystack.co/v1/inline.js">
const paymentForm = document.getElementById('paymentForm');
paymentForm.addEventListener("submit", payWithPaystack, false);
function payWithPaystack(e) {
  e.preventDefault();

  let handler = PaystackPop.setup({
    key: 'pk_test_dae7533de99c967efdc0d64ac5f5ff78a7107aa8', // Replace with your public key
    email: document.getElementById("babalolakehinde@gmail.com").value,
    amount: document.getElementById("3000").value * 100,
    ref: ''+Math.floor((Math.random() * 1000000000) + 1), // generates a pseudo-unique reference. Please replace with a reference you generated. Or remove the line entirely so our API will generate one for you
    // label: "Optional string that replaces customer email"
    onClose: function(){
      alert('Window closed.');
    },
    callback: function(response){
      let message = 'Payment complete! Reference: ' + response.reference;
      alert(message);
    }
  });

  handler.openIframe();
}


</script> 
<form action="/save-order-and-pay" method="POST"> 
<input type="hidden" name="user_email" value="<?php echo $email; ?>"> 
<input type="hidden" name="amount" value="<?php echo $amount; ?>"> 
<input type="hidden" name="cartid" value="<?php echo $cartid; ?>"> 
<button type="submit" name="pay_now" id="pay-now" title="Pay now">Pay now</button>
</form>
<?php
include('db.php');


// integration of paystack

if (isset($_POST{"submit"}) ){
  $email = htmlspecialchars($_POST["email"]);

  // initiate paystack
$url = "https://api.paystack.co/transaction/initialize";
//   getther the body params
$transation_data -[
"email" => $email,
"amount"=> $price * 100,
"callback_url"=> "http:/localhost/beatrice/verify.php",
"metadata" => [
  "custom_fields"=>[
      [
          "display_name" => "name",
          "varible_name"=> "name",
          "value" => $name
      ],
      [
          "display_name" => "price",
          "varible_name"=> "price",
          "value" => $price
      ],
      [
          "display_name" => "discription",
          "varible_name"=> "discription",
          "value" => $discription
      ],
  ]
]


];
// generate a URL -encoded string
$encode_transaction_data = http_build_query($transaction_data);
//  open connect to cURL
$ch = curl_int();
//  set the url
curl_setopt($ch, CURLOPT_URL,$url);
// enable data to be sent in POST array
curl_setopt($ch,CURLOPT_POST, true);
// collect the posted data from above
curl_setopt($ch, CURLOPT_POSTFIELDS,$encode_transaction_data );
// SET THE HEADER FROM THE END OINT
curl_setopt($ch,CURLPOST_HTTPHEADER, array(
  "Authorization: Bearer sk_test_f0edca6140cb9f6c612d93c49765f2192af2691a",
  "cache-control: no-cache" 
));
// make curl return the data instead of encodin it
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
//  execute cURL
$results =- curl_exec($ch);
//  check for errors
$errors = curl_error($ch);
if ($errors) {
die ("Curl returned some errors:". $errors);
$transaction= json_decode( $result );
 header("location:". $transaction->data->author
};


?>  
<?php

$url = "https://api.paystack.co/transaction/initialize";

$fields = [
  'email' => "customer@email.com",
  'amount' => "20000"
];

$fields_string = http_build_query($fields);

//open connection
$ch = curl_init();

//set the url, number of POST vars, POST data
curl_setopt($ch,CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch,CURLOPT_POSTFIELDS, $fields_string);
curl_setopt($ch, CURLOPT_HTTPHEADER, array(
  "Authorization: Bearer sk_test_f0edca6140cb9f6c612d93c49765f2192af2691a",
  "Cache-Control: no-cache",
));

//So that curl_exec returns the contents of the cURL; rather than echoing it
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true); 

//execute post
$result = curl_exec($ch);
echo $result;
?>


<?php
// integration of paystack

if (isset($_POST{"submit"}) ){
$email = htmlspecialchars($_POST["email"]);

// initiate paystack
$url = "https://api.paystack.co/transaction/initialize";
//   getther the body params
$transation_data -[
"email" => $email,
"amount"=> $price * 100,
"callback_url"=> "http:/localhost/beatrice/verify.php",
"metadata" => [
"custom_fields"=>[
    [
        "display_name" => "name",
        "varible_name"=> "name",
        "value" => $name
    ],
    [
        "display_name" => "price",
        "varible_name"=> "price",
        "value" => $price
    ],
    [
        "display_name" => "discription",
        "varible_name"=> "discription",
        "value" => $discription
    ],
]
]


];
// generate a URL -encoded string
$encode_transaction_data = http_build_query($transaction_data);
//  open connect to cURL
$ch = curl_int();
//  set the url
curl_setopt($ch, CURLOPT_URL,$url);
// enable data to be sent in POST array
curl_setopt($ch,CURLOPT_POST, true);
// collect the posted data from above
curl_setopt($ch, CURLOPT_POSTFIELDS,$encode_transaction_data );
// SET THE HEADER FROM THE END OINT
curl_setopt($ch,CURLPOST_HTTPHEADER, array(
"Authorization: Bearer sk_test_f0edca6140cb9f6c612d93c49765f2192af2691a",
"cache-control: no-cache" 
));
// make curl return the data instead of encodin it
curl_setopt($ch,CURLOPT_RETURNTRANSFER, true);
//  execute cURL
$results = curl_exec($ch);
//  check for errors
$errors = curl_error($ch);
if ($errors) {
die ("Curl returned some errors:". $errors);

}
var_dump($results);
}
?>  
$curl = curl_init();
  
  curl_setopt_array($curl, array(
    CURLOPT_URL => "https://api.paystack.co/transaction/verify/:reference",
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_ENCODING => "",
    CURLOPT_MAXREDIRS => 10,
    CURLOPT_TIMEOUT => 30,
    CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
    CURLOPT_CUSTOMREQUEST => "GET",
    CURLOPT_HTTPHEADER => array(
      "Authorization: Bearer sk_test_f0edca6140cb9f6c612d93c49765f2192af2691a",
      "Cache-Control: no-cache",
    ),
  ));
  
  $response = curl_exec($curl);
  $err = curl_error($curl);

  curl_close($curl);
  
  if ($err) {
    echo "cURL returned some error:" . $err;
  } else {
    echo $response;
  }