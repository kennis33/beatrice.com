<?php
$db_host= "localhost:3306";
$db_username= "maxedtnx_beatrice";
$db_password= "07032783760";
$db_name= "maxedtnx_beatricewears";

$db= mysqli_connect($db_host,$db_username, $db_password,$db_name);
 if(!$db){
    die( "error in connection:". mysqli_connect_error());
 }



?>