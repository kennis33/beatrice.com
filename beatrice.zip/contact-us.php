
<?php
if(isset($_POST['submit'])){
	$name = trim($_POST['name']);
	$email = trim($_POST['email']);
	$subject = trim($_POST['subject']);
	$message = trim($_POST['message']);

	$myMail= 'admin@beatricewears.ga';
	$header = "from:". $email;
	$txt = "you have received a message from ". $name .".\n\n" . $message;
}else{
	(mail($myMail, $subject,$txt,$header)); 

	header("location:index.php?emailsend");
	
}
?>

